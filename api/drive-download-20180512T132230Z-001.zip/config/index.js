module.exports = {
    bdd : {
      host : 'localhost',
      dialect : 'mysql',
      dbname : 'my_corp_guardian',
      user : 'root',
      password : '',
      port : 3306
    }
}
