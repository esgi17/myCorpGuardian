const ModelIndex = require('../models');
const Pass = ModelIndex.Pass;
const Op = ModelIndex.sequelize.Op;

const PassController = function() { };








// Export du controller
module.exports = PassController;
