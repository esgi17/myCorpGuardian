module.exports = {
  UserController: require('./user'),
  PassController: require('./pass')
}
